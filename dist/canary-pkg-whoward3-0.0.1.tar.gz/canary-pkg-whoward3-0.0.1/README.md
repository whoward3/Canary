# Canary

Identifying the Optimal Placement of DDoS Model Checkers (Canaries) in Undirected Network Enviroments

As the power of Distributed Denial of Service Attacks increases, early detection and mitigation become ever so important. Project Canary aims to define a rapid detection and mitigation technique to counter the aforementioned DDoS attacks.