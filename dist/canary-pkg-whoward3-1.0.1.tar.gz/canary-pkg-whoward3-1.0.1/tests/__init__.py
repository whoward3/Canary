"""
tests

The test suite for the canaryScripts
"""

__all__ = ["test_canary"]